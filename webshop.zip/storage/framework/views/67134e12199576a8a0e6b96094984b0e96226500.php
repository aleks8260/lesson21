<?php $__env->startSection('content'); ?>
    список продуктов
    <table class="table table-striped">
        <tr>
            <td>Title</td>
            <td>content</td>
            <td>price</td>
            <td>update</td>
            <td>delete</td>
        </tr>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($product->title); ?></td>
            <td><?php echo e($product->content); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><a href="#" class="btn btn-success">Update</a></td>
            <td><a href="#"  class="btn btn-danger">Delete</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>