<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
    <body>
        <form action="<?php echo e(route('product.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="title" placeholder="title">
            <input type="text" name="content" placeholder="content">
            <input type="text" name="price" placeholder="price">
            <input type="submit">
        </form>
    </body>
    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>