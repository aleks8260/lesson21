<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //Возвращает view админ панели
    public function dashboard(){
        return view('admin.layout');
    }
}
