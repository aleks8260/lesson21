<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //встроенная переменная филабел
    protected $fillable = [
        'title', 
        'content',
        'price'
    ];
}
