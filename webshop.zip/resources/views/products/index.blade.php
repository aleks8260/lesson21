@extends('admin.layout')

@section('content')
    список продуктов
    <table class="table table-striped">
        <tr>
            <td>Title</td>
            <td>content</td>
            <td>price</td>
            <td>update</td>
            <td>delete</td>
        </tr>

    @foreach($products as $product)
        
        <tr>
            <td>{{$product->title}}</td>
            <td>{{$product->content}}</td>
            <td>{{$product->price}}</td>
            <td><a href="#" class="btn btn-success">Update</a></td>
            <td><a href="#"  class="btn btn-danger">Delete</a></td>
        </tr>
    @endforeach
    </table>
@endsection